8"""88                    8""""8                        
8    8 ee   e eeee eeeee  8      eeee eeeee eeeee  eeee 
8    8 88   8 8    8   8  8eeeee 8  8 8  88 8   8  8    
8    8 88  e8 8eee 8eee8e     88 8e   8   8 8eee8e 8eee 
8    8  8  8  88   88   8 e   88 88   8   8 88   8 88   
8eeee8  8ee8  88ee 88   8 8eee88 88e8 8eee8 88   8 88ee 
                                                        
              8""8""8                     
              8  8  8 eeee eeeee e  eeeee 
              8e 8  8 8    8   8 8  8   8 
              88 8  8 8eee 8e  8 8e 8eee8 
              88 8  8 88   88  8 88 88  8 
              88 8  8 88ee 88ee8 88 88  8
			  
		  --------------------------------------
            _                                    		  
----------  OverScore Media's Brand Assets Pack ----------
                                               
		  --------------------------------------

### Thanks for downloading!

-----
## Our Brand Colours:
  - *OverDark*
    - #262626
	- hsl(0, 0%, 15%)
  - *Dargrey*
    - #989eb9
	- hsl(229, 19%, 66%)
  - *Magentish*
    - #cf5986
	- hsl(337, 55%, 58%)
  - *Greenwich*
    - #59cfa2
	- hsl(157, 55%, 58%)
  - *Blue.sh*
    - #008dd5
	- hsl(200, 100%, 84%)
	
(We find that Magentish and Greenwich probably
go best together - next best would be an OverDark 
background with either of Magentish, Greenwich, and Blue.sh)
-----

-----
## You'll find the following in this pack:
  - Image Formats:
    - SVG logos (Vector)
    - PNG logos (Raster/Bitmap)
  - Types of Logos:            _
    - Favicons - Our Signature O
	- Full Icons
	- OverScore Only (No Media in logo)
  - Backgrounds:
    - White
	  - Transparent
	  - OverDark (#262626) - Where Applicable
-----

Thanks http://www.network-science.de/ascii/ for the generated
ASCII art, and https://jakearchibald.github.io/svgomg/ for the
SVG optimization (using SVGO)!

See https://overscore.media/brand for more information.

Let us know if you could use any other colour/border variants/
combinations.

Get ready to Level Up! ;)

+++++    Logos are Copyright 2020 - OverScore Media    +++++

     /================================================\
 /===                                                  ===\
|                                                          |
|              https://dev.to/overscoremedia               |
=====   @overscoremedia (Twitter/Facebook/Pinterest)   =====
=====           @overscore_media (Instagram)           =====
=====           @overscore-media (GitHub)              =====
|                 --> overscore.media <--                  |
|                                                          |
\===                                                  ====/
    \================================================/